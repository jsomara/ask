==========
Askbot API
==========

Askbot has API to access forum data in read-only mode.
Current version of API is 1.

All urls start with `/api/v1` and the following endpoints are available::
*`/api/v1/info/forum/`
*`/api/v1/info/users/`
*`/api/v1/info/users/<user_id>/`
*`/api/v1/info/questions/`
*`/api/v1/info/questions/<question_id>/`
