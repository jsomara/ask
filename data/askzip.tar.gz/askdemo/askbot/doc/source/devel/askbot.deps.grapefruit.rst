.. _askbot.deps.grapefruit:

:mod:`askbot.deps.grapefruit`
======================

.. automodule:: askbot.deps.grapefruit
    :members:
    :undoc-members:
    :show-inheritance:

