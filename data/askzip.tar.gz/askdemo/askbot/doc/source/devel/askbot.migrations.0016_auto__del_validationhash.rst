.. _askbot.migrations.0016_auto__del_validationhash:

:mod:`askbot.migrations.0016_auto__del_validationhash`
===============================================

.. automodule:: askbot.migrations.0016_auto__del_validationhash
    :members:
    :undoc-members:
    :show-inheritance:

