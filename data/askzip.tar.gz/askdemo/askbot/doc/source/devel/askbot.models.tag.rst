.. _askbot.models.tag:

:mod:`askbot.models.tag`
=================

.. automodule:: askbot.models.tag
    :members:
    :undoc-members:
    :show-inheritance:

