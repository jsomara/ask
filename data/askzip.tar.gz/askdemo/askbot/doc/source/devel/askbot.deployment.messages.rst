.. _askbot.deployment.messages:

:mod:`askbot.deployment.messages`
==========================

.. automodule:: askbot.deployment.messages
    :members:
    :undoc-members:
    :show-inheritance:

