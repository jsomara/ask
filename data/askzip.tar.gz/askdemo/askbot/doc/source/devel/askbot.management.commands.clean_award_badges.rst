.. _askbot.management.commands.clean_award_badges:

:mod:`askbot.management.commands.clean_award_badges`
=============================================

.. automodule:: askbot.management.commands.clean_award_badges
    :members:
    :undoc-members:
    :show-inheritance:

