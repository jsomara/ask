.. _askbot.migrations.0001_initial:

:mod:`askbot.migrations.0001_initial`
==============================

.. automodule:: askbot.migrations.0001_initial
    :members:
    :undoc-members:
    :show-inheritance:

