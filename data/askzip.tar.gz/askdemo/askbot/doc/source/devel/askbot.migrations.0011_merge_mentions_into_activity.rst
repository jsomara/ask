.. _askbot.migrations.0011_merge_mentions_into_activity:

:mod:`askbot.migrations.0011_merge_mentions_into_activity`
===================================================

.. automodule:: askbot.migrations.0011_merge_mentions_into_activity
    :members:
    :undoc-members:
    :show-inheritance:

