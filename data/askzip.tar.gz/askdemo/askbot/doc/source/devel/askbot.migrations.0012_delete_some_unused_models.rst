.. _askbot.migrations.0012_delete_some_unused_models:

:mod:`askbot.migrations.0012_delete_some_unused_models`
================================================

.. automodule:: askbot.migrations.0012_delete_some_unused_models
    :members:
    :undoc-members:
    :show-inheritance:

