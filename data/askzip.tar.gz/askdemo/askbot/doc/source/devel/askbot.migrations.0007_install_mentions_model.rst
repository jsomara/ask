.. _askbot.migrations.0007_install_mentions_model:

:mod:`askbot.migrations.0007_install_mentions_model`
=============================================

.. automodule:: askbot.migrations.0007_install_mentions_model
    :members:
    :undoc-members:
    :show-inheritance:

