.. _askbot.management.commands.add_admin:

:mod:`askbot.management.commands.add_admin`
====================================

.. automodule:: askbot.management.commands.add_admin
    :members:
    :undoc-members:
    :show-inheritance:

