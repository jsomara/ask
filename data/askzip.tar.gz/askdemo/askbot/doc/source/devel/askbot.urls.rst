.. _askbot.urls:

:mod:`askbot.urls`
===========

.. automodule:: askbot.urls
    :members:
    :undoc-members:
    :show-inheritance:

