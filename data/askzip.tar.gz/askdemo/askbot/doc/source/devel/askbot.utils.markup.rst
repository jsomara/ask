.. _askbot.utils.markup:

:mod:`askbot.utils.markup`
===================

.. automodule:: askbot.utils.markup
    :members:
    :undoc-members:
    :show-inheritance:

