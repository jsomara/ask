.. _askbot.migrations.0013_add_response_count__to_user:

:mod:`askbot.migrations.0013_add_response_count__to_user`
==================================================

.. automodule:: askbot.migrations.0013_add_response_count__to_user
    :members:
    :undoc-members:
    :show-inheritance:

