.. _askbot.migrations.0015_rename_forum_contenttypes_to_askbot:

:mod:`askbot.migrations.0015_rename_forum_contenttypes_to_askbot`
==========================================================

.. automodule:: askbot.migrations.0015_rename_forum_contenttypes_to_askbot
    :members:
    :undoc-members:
    :show-inheritance:

