.. _askbot.management.commands.pg_once_award_badges:

:mod:`askbot.management.commands.pg_once_award_badges`
===============================================

.. automodule:: askbot.management.commands.pg_once_award_badges
    :members:
    :undoc-members:
    :show-inheritance:

